#ifndef FG_AND_BG_H
#define FG_AND_BG_H

#include "main.h"


void fg_command(pid_t pid);
void bg_command(pid_t pid);

#endif
