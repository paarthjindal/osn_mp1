#ifndef ACTIVITIES_H
#define ACTIVITES_H
#include "main.h"

int compare_processes(const void *a, const void *b) ;

void print_activities() ;

#endif