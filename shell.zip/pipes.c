#include "pipes.h"

// Function to execute piped commands
