#ifndef SYSTEM_COMMANDS_H
#define SYSTEM_COMMANDS_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>

void prompt(char * home_direc);


#endif