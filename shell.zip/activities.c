#include "activites.h"

extern int process_count;
int compare_processes(const void *a, const void *b)
{
    back_proc_list *procA = (back_proc_list *)a;
    back_proc_list *procB = (back_proc_list *)b;
    return strcmp(procA->process_name, procB->process_name);
}

void print_activities()
{
    // Sort the background processes lexicographically by command name
    qsort(background_process_list, process_count, sizeof(back_proc_list), compare_processes);

    // Iterate through the background processes and check their actual status
    for (int i = 0; i < process_count; i++)
    {
        pid_t pid = background_process_list[i].process_id;
        int status;

        // Use waitpid with WNOHANG to check the process status without blocking
        if (waitpid(pid, &status, WNOHANG) == 0)
        {
            // Process is still running or stopped, use kill to check specific state
            if (kill(pid, 0) == 0)
            {
                // Process is still alive, check if it's stopped
                if (kill(pid, SIGCONT) == -1 && errno == ESRCH)
                {
                    // Process is stopped
                    printf("[%d] : %s - Stopped\n", pid, background_process_list[i].process_name);
                }
                else
                {
                    // Process is running
                    printf("[%d] : %s - Running\n", pid, background_process_list[i].process_name);
                }
            }
            else
            {
                // Process is no longer running
                printf("[%d] : %s - Exited\n", pid, background_process_list[i].process_name);
            }
        }
        else
        {
            // Process has terminated
            printf("[%d] : %s - Exited\n", pid, background_process_list[i].process_name);
        }
    }
}