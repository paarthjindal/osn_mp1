#ifndef SIGNALS_H
#define SIGNALS_H

#include "main.h"
void handle_ping(char *pid_str, char *signal_num_str) ;


#endif
