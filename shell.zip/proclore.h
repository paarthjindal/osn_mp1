#ifndef PROCLORE_H
#define PROCLORE_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

void describe_process(pid_t process_id);

#endif